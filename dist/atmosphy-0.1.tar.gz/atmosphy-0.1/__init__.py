import os
from shutil import copyfile
import initialize

# Generate the once-off ~/.atmosphy directory
atmosphyUserPath = os.path.expanduser('~/.atmosphy')

if not os.path.exists(atmosphyUserPath):
    print "atmosphy dir there"
    os.makedirs(atmosphyUserPath)

# Copy the config file into the user home directory
if not os.path.exists(os.path.join(atmosphyUserPath, 'config.ini')):
    print "config dir there"
    copyfile(os.path.join(os.path.realpath(__file__), 'config.ini'), os.path.join(atmosphyUserPath, 'config.ini'))

# checking for database and creating if it does not exist:

if not os.path.exists(os.path.join(atmosphyUserPath, 'atmosphy.db3')):
    print "init db there"
    initialize.initModelDB()
    
