import sqlite3
import os


def atmosStoragePath(filename=''):
    return os.path.expanduser(os.path.join('~/.atmosphy', filename))


def initModelDB(dbPath=atmosStoragePath('atmosphy.db3'), clobber = False):
    	"""Initialize the database with a model at the dbPath location"""
    	
    	if not os.path.exists(os.path.dirname(dbPath)): os.system('mkdir %s' %os.path.dirname(dbPath))
    	
    	initModelsTable = """CREATE TABLE models(model_name STRING, 
    										model_description STRING,
    										model_url STRING,
    										model_ondisk BOOL DEFAULT 0)"""
    	
    	if os.path.exists(dbPath):
    		if clobber: 
	    		print "Warning: Overwriting database"
	    		os.remove(dbPath)

			
    	connection = sqlite3.connect(os.path.abspath(dbPath))
    	connection.execute(initModelsTable)
    	connection.commit()
    	connection.close()
    	
    	return None
    	




