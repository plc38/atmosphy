#!/usr/bin/env python

from distutils.core import setup
import os

try: # Python 3.x
    from distutils.command.build_py import build_py_2to3 as build_py
except ImportError: # Python 2.x
    from distutils.command.build_py import build_py


setup(name='atmosphy',
      version='0.155',
      description='Stellar atmosphere models in Python',
      author='Wolfgang Kerzendorf and Andy Casey',
      classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Console'],
                    
      author_email='wkerzendorf@mso.anu.edu.au, \
        acasey@mso.anu.edu.au',
      url='',
      packages = ['atmosphy'],
      package_dir = {'atmosphy':'.'},
      package_data = {'atmosphy': ['conf.d/config.ini', 'conf.d/atmosphy.db3']},
      cmdclass = {'build_py':build_py},
      scripts = ["scripts/atmosphy", "scripts/atmosphy_getgrid"],
#      data_files = [('conf.d/', ['conf.d/config.ini', 'conf.d/atmosphy.db3'])],
      #install_requires = ['argparse>=1.1', 'scipy>0.9.0.dev6903']
      install_requires = ['argparse>=1.1']
     )


